from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

from .texts import CURRENCY_LABEL, line
from .utils.amounts import format_rial
from .utils.jalali import (
    fa_digits,
    iran_week_bounds,
    jalali_date_label,
    jalali_month_bounds,
    local_day_bounds,
    previous_period_bounds,
)

if TYPE_CHECKING:
    from .database import Database


def _local_bounds(period: str, tz) -> tuple[datetime, datetime]:
    now = datetime.now(tz)
    if period == "week":
        return iran_week_bounds(now)
    if period == "month":
        return jalali_month_bounds(now)
    if period == "today":
        return local_day_bounds(now)
    raise ValueError(f"Unsupported period: {period}")


def _range_label(start: datetime, end: datetime) -> str:
    end_display = end.astimezone(start.tzinfo) - timedelta(days=1)
    return f"{jalali_date_label(start)} تا {jalali_date_label(end_display)}"


def _period_label(period: str) -> str:
    return {"today": "امروز", "week": "این هفته", "month": "این ماه"}[period]


def _comparison_label(period: str) -> str:
    return {"today": "دیروز", "week": "هفته قبل", "month": "ماه قبل"}[period]


def _percent_change(current: int, previous: int) -> str:
    if previous == 0 and current == 0:
        return "بدون تغییر"
    if previous == 0:
        return "شروع از صفر"
    change = ((current - previous) / previous) * 100
    sign = "+" if change >= 0 else ""
    return f"{sign}{fa_digits(f'{change:.0f}')}٪"


def _to_utc_iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat()


def _transaction_line(row) -> str:
    category = row["category"] or "بدون دسته‌بندی"
    created = datetime.fromisoformat(row["created_at"])
    return line("report_details", f"{jalali_date_label(created)} | {row['title']} - ({category}) | {format_rial(int(row['amount']))}", "📋")


async def build_report(db: Database, user_id: int, period: str, tz) -> str:
    start, end = _local_bounds(period, tz)
    rows = await db.transactions_between(user_id, _to_utc_iso(start), _to_utc_iso(end))
    prev_start, prev_end = previous_period_bounds(start, end)
    previous_rows = await db.transactions_between(user_id, _to_utc_iso(prev_start), _to_utc_iso(prev_end))

    expense = sum(int(row["amount"]) for row in rows if row["kind"] == "expense")
    income = sum(int(row["amount"]) for row in rows if row["kind"] == "income")
    previous_expense = sum(int(row["amount"]) for row in previous_rows if row["kind"] == "expense")
    previous_income = sum(int(row["amount"]) for row in previous_rows if row["kind"] == "income")
    balance = income - expense
    expense_count = sum(1 for row in rows if row["kind"] == "expense")
    income_count = sum(1 for row in rows if row["kind"] == "income")
    avg_expense = int(expense / expense_count) if expense_count else 0

    expense_by_cat: dict[str, int] = defaultdict(int)
    for row in rows:
        category = row["category"] or "بدون دسته‌بندی"
        if row["kind"] == "expense":
            expense_by_cat[category] += int(row["amount"])

    label = _period_label(period)
    report_emoji = "report_week" if period == "week" else "report_month"
    if period == "today":
        report_emoji = "chart"

    lines = [
        line(report_emoji, f"گزارش {label}", "📊"),
        line("report_details", f"بازه شمسی: {_range_label(start, end)}", "📅"),
        "",
        line("expense", f"کل هزینه: {format_rial(expense)}", "💸"),
        line("income", f"کل درآمد: {format_rial(income)}", "💵"),
        line("chart", f"مانده: {'+' if balance >= 0 else '-'}{format_rial(abs(balance))}", "📊"),
        line("expense", f"تعداد هزینه‌ها: {expense_count}", "💸"),
        line("income", f"تعداد درآمدها: {income_count}", "💵"),
    ]

    if avg_expense:
        lines.append(line("expense", f"میانگین هر هزینه: {format_rial(avg_expense)}", "💸"))

    lines.extend([
        "",
        line("chart", f"مقایسه با {_comparison_label(period)}", "📊"),
        line("expense", f"هزینه: {format_rial(expense)} / قبل: {format_rial(previous_expense)} ({_percent_change(expense, previous_expense)})", "💸"),
        line("income", f"درآمد: {format_rial(income)} / قبل: {format_rial(previous_income)} ({_percent_change(income, previous_income)})", "💵"),
    ])

    if not rows:
        lines.extend(["", line("report_empty", "هنوز چیزی برای این بازه ثبت نشده.", "⚠️")])
        return "\n".join(lines)

    if expense_by_cat:
        lines.extend(["", line("expense", "بیشترین هزینه‌ها:", "💸")])
        for category, amount in sorted(expense_by_cat.items(), key=lambda item: item[1], reverse=True)[:5]:
            lines.append(line("category", f"{category}: {format_rial(amount)}", "🏷"))

    expense_rows = [row for row in rows if row["kind"] == "expense"]
    if expense_rows:
        lines.extend(["", line("report_details", "ریز هزینه‌ها:", "📋")])
        for row in expense_rows:
            lines.append(_transaction_line(row))

    lines.append("\n" + line("money", f"واحد همه مبالغ: {CURRENCY_LABEL}", "💰"))
    return "\n".join(lines)


def format_recent(rows: list) -> str:
    if not rows:
        return line("recent_empty", "هنوز تراکنشی ثبت نکردی.", "⚠️")

    lines = [line("recent", "آخرین تراکنش‌ها:", "🧾"), ""]
    for row in rows:
        sign = "-" if row["kind"] == "expense" else "+"
        created = datetime.fromisoformat(row["created_at"])
        date_label = jalali_date_label(created)
        if row["kind"] == "expense":
            category = row["category"] or "بدون دسته‌بندی"
            lines.append(line("recent", f"{date_label} | {sign} {row['title']} | {format_rial(int(row['amount']))} | {category}", "🧾"))
        else:
            lines.append(line("recent", f"{date_label} | {sign} {row['title']} | {format_rial(int(row['amount']))}", "🧾"))
    return "\n".join(lines)
